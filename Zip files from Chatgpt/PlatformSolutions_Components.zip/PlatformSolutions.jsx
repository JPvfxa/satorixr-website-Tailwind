import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import SolutionCard from "./SolutionCard";

const TOTAL_FRAMES = 101;
const FRAME_PATH = (index) =>
  new URL(
    `./assets/car_frames/car_${(10001 + index).toString().padStart(5, "0")}.png`,
    import.meta.url
  ).href;

const PlatformSolutions = () => {
  const canvasRef = useRef(null);
  const [images, setImages] = useState([]);

  useEffect(() => {
    const loadImages = async () => {
      const imgArr = [];
      for (let i = 0; i < TOTAL_FRAMES; i++) {
        const img = new Image();
        img.src = FRAME_PATH(i);
        imgArr.push(img);
      }
      setImages(imgArr);
    };
    loadImages();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let currentFrame = 0;

    const render = () => {
      if (images[currentFrame]) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(images[currentFrame], 0, 0, canvas.width, canvas.height);
      }
    };

    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const maxScroll = document.body.scrollHeight - window.innerHeight;
      const scrollFraction = scrollTop / maxScroll;
      currentFrame = Math.min(
        TOTAL_FRAMES - 1,
        Math.floor(scrollFraction * TOTAL_FRAMES)
      );
      render();
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [images]);

  return (
    <div className="flex flex-col items-center gap-12 px-4 py-12 max-w-7xl mx-auto">
      <h2 className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-900 text-3xl sm:text-4xl font-[Montserrat] text-center">
        Platform Solutions
      </h2>

      <div className="flex flex-col lg:flex-row items-center gap-8 w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="w-full lg:w-1/2"
        >
          <SolutionCard
            image="/src/components/assets/sales-xtreme.png"
            description="Revolutionizing Product Sales with Immersive XR Technologies"
          />
        </motion.div>

        <div className="w-full lg:w-1/2">
          <canvas ref={canvasRef} width="800" height="400" className="w-full h-auto" />
        </div>
      </div>
    </div>
  );
};

export default PlatformSolutions;