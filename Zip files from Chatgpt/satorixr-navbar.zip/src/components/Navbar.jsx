import React, { useState } from "react";
import { PrimaryButton } from "./PrimaryButton";
import logo from "../assets/logo.svg";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="w-full bg-[#05050503] border-b border-[#ffffff33] backdrop-blur-lg backdrop-brightness-100 px-6 py-4">
      <div className="max-w-[1440px] mx-auto flex items-center justify-between">
        {/* Logo */}
        <img src={logo} alt="Logo" className="w-[151px] h-[23px]" />

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-6 font-nav-bar text-white text-sm">
          <div>Capabilities</div>
          <div>Solutions</div>
          <div>Industries</div>
          <div>About</div>
        </div>

        {/* Right Side - Button and Links */}
        <div className="hidden lg:flex items-center gap-6">
          <div className="font-semibold text-white text-sm">Resources</div>
          <div className="font-semibold text-white text-sm">Pricing</div>
          <PrimaryButton className="!flex-shrink-0" />
        </div>

        {/* Mobile Toggle */}
        <div className="lg:hidden">
          <button onClick={() => setMenuOpen(!menuOpen)} className="text-white">
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="lg:hidden mt-4 space-y-3 font-nav-bar text-white text-sm">
          <div>Capabilities</div>
          <div>Solutions</div>
          <div>Industries</div>
          <div>About</div>
          <div className="font-semibold">Resources</div>
          <div className="font-semibold">Pricing</div>
          <PrimaryButton className="mt-2" />
        </div>
      )}
    </nav>
  );
};

export default Navbar;
