import React from "react";

export const PrimaryButton = ({ className }) => {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#FFD900] to-[#64591B] text-white text-base font-medium font-nav-bar ${className}`}
    >
      <span>Get Started</span>
      <svg className="w-[16px] h-[10px]" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.59 0L9.17 1.41 12.75 5 9.17 8.59 10.59 10 16 5.00001 10.59 0ZM0 4V6H14V4H0Z" fill="white"/>
      </svg>
    </button>
  );
};
