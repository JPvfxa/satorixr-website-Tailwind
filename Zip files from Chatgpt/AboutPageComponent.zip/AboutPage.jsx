
import React from "react";
import HeroSection from "../components/HeroSection";

const AboutPage = () => {
  return (
    <div className="bg-black text-white">
      <HeroSection />
      <section className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-semibold mb-6 font-nav-bar text-variable-collection-satori-gold">
          About Satori XR
        </h2>
        <p className="text-lg leading-7 font-p3 text-variable-collection-white">
          At Satori XR, we empower industries with immersive training, virtual simulations,
          and real-time collaboration through cutting-edge XR technologies. Our solutions
          are designed to transform capabilities and enhance operational excellence.
        </p>
      </section>
    </div>
  );
};

export default AboutPage;
