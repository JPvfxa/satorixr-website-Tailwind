import React from "react";

const LabelSection = () => {
  return (
    <section className="max-w-4xl mx-auto px-4 py-8 text-center">
      <p className="text-[22.5px] leading-[1.3] font-normal text-transparent bg-clip-text bg-gradient-to-t from-[rgba(0,0,0,1)] to-[rgba(224,204,84,1)] font-[Montserrat]">
        SatoriXR draws inspiration from the Japanese term Satori (悟り), meaning
        enlightenment — a moment of true understanding.
        <br />
        <br />
        Our platform uses immersive 3D, XR, and Digital Twin technologies to
        help visualize and deeply understand complex phenomena, products, and
        principles.
      </p>
    </section>
  );
};

export default LabelSection;