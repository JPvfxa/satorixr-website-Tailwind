
import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import lightsL from "./assets/lights-l.png";
import lightsR from "./assets/lights-r.png";
import satoriCircle from "./assets/satori-circle.svg";
import stars2 from "./assets/stars-2.svg";
import stars3 from "./assets/stars-3.svg";
import stars4 from "./assets/stars-4.svg";
import stars5 from "./assets/stars-5.svg";
import starsS from "./assets/stars-s.png";
import stars from "./assets/stars.svg";

const HeroSection = () => {
  const heroRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(".fade-in", { opacity: 0 }, { opacity: 1, duration: 1.5 });
    }, heroRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={heroRef} className="relative w-full min-h-screen flex items-center justify-center overflow-hidden bg-black">
      <div className="absolute w-[2375px] h-[1499px] top-[-670px] left-[-200px] pointer-events-none">
        <div className="relative w-full h-full">
          <div className="absolute w-[1267px] h-[925px] top-0 left-[265px] rounded-[633.56px/462.46px] blur-[142.05px] bg-[radial-gradient(50%_50%_at_36%_49%,rgba(226,226,226,0.4)_0%,rgba(0,0,0,0.4)_100%)]" />

          <img className="absolute w-[593px] h-[583px] top-[670px] left-[847px]" src={lightsR} alt="Lights Right" />
          <img className="absolute w-[559px] h-[521px] top-[849px] left-0" src={lightsL} alt="Lights Left" />
          <img className="absolute w-[768px] h-[310px] top-[806px] left-[327px]" src={starsS} alt="Stars S" />

          <div className="absolute w-[1136px] h-[473px] top-[773px] left-[188px]">
            <img className="absolute w-2 h-2 top-[202px] left-[140px]" src={stars} alt="Stars" />
            <img className="absolute w-[13px] h-[13px] top-[387px] left-[7px]" src={stars5} alt="Stars5" />
            <img className="absolute w-[17px] h-[17px] top-5 left-[811px]" src={stars2} alt="Stars2" />
            <img className="absolute w-2.5 h-2.5 top-0 left-0" src={stars3} alt="Stars3" />
            <img className="absolute w-[17px] h-[17px] top-[136px] left-[1119px]" src={stars4} alt="Stars4" />
          </div>

          <img className="absolute w-[620px] h-[620px] top-[725px] left-[410px]" src={satoriCircle} alt="Satori Circle" />
        </div>
      </div>

      <div className="relative text-center text-white z-10 fade-in">
        <h2 className="text-[22.5px] font-semibold bg-gradient-to-r from-[#FFD900] to-[#64591B] bg-clip-text text-transparent">SATORI XR</h2>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-normal font-['Montserrat'] leading-tight">EMPOWERING</h1>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-normal font-['Montserrat'] leading-tight">EDUCATION · TRAINING · SALES</h1>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-normal font-['Montserrat'] leading-tight">WITH IMMERSIVE XR</h1>
      </div>
    </section>
  );
};

export default HeroSection;
