import React, { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import image28 from "./image-28.png";

gsap.registerPlugin(ScrollTrigger);

export const Image = () => {
  const imageRef = useRef(null);

  useEffect(() => {
    const el = imageRef.current;
    gsap.fromTo(
      el,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: "power2.out",
        scrollTrigger: {
          trigger: el,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
      }
    );
  }, []);

  return (
    <div
      ref={imageRef}
      className="w-full max-w-[896px] h-auto mx-auto px-4 sm:px-8 md:px-12"
    >
      <img
        className="w-full h-auto object-cover rounded-lg"
        alt="Image"
        src={image28}
      />
    </div>
  );
};
