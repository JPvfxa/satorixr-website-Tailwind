
import React, { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const LabelSection = () => {
  const textRef = useRef(null);

  useEffect(() => {
    const el = textRef.current;
    gsap.fromTo(
      el,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1.5,
        ease: "power2.out",
        scrollTrigger: {
          trigger: el,
          start: "top 80%",
          toggleActions: "play none none none",
        },
      }
    );
  }, []);

  return (
    <section className="w-full min-h-screen flex items-center justify-center px-4 overflow-hidden">
      <div className="max-w-[906px]">
        <p
          ref={textRef}
          className="text-[22.5px] text-center leading-[25.5px] font-normal font-p3 bg-clip-text text-transparent"
          style={{
            backgroundImage:
              "linear-gradient(359deg, #FFD900 0%, #64591B 50%, #000000 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          SatoriXR draws inspiration from the Japanese term Satori (悟り),
          meaning enlightenment — a moment of true understanding.
          <br />
          <br />
          Our platform uses immersive 3D, XR, and Digital Twin technologies to
          help visualize and deeply understand complex phenomena, products, and
          principles.
        </p>
      </div>
    </section>
  );
};

export default LabelSection;
